<?php
/**
 * Template Name: Resource List
 */
get_header();
?>

<form id="resource-filter-form" name="resource_filter" post="" action="">
    <select id="resource-type">
        <option value="">Select Resource Type</option>
        <?php
        $resource_types = get_terms(array(
            'taxonomy' => 'resource_type',
            'hide_empty' => false,
        ));
        foreach ($resource_types as $type) {
            echo '<option value="' . $type->term_id . '">' . $type->name . '</option>';
        }
        ?>
    </select>

    <select id="resource-topic">
        <option value="">Select Resource Topic</option>
        <?php
        $resource_topics = get_terms(array(
            'taxonomy' => 'resource_topic',
            'hide_empty' => false,
        ));
        foreach ($resource_topics as $topic) {
            echo '<option value="' . $topic->term_id . '">' . $topic->name . '</option>';
        }
        ?>
    </select>

    <input type="text" id="resource-keyword" placeholder="Enter keyword">

    <button type="submit">Filter</button>
</form>

<div id="resource-list">
    <?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            get_template_part('template-parts/content', 'resource');
        endwhile;
    else :
        echo 'No resources found.';
    endif;
    ?>
</div>

<?php
get_footer();
